let score = 0
let isPaused = false
var arr = [] // walls
var BombePlace = [] // where can we puts bombs
var HeroBomb = false

const ele = document.getElementById("map"); // map

for (let i = 0; i <= 12; i++) {
  for (let j = 0; j <= 16; j++) {
    const elem = document.createElement('div');
    if (j === 0 || j === 16 || i === 12 || i === 0 || (j % 2 === 0 && i % 2 === 0)) {
      elem.style.width = '32px';
      elem.style.height = '32px';
      elem.style.backgroundImage = 'url("media/tile.png")';
      arr.push({ top: (i * 32), left: j * 32 })
    } else {
      elem.dataset.i = i;
      elem.dataset.j = j;
      elem.dataset.bg = "green"
      elem.style.backgroundImage = 'url("media/greenBlock.png")'
    }
    elem.style.position = "absolute";
    elem.style.height = '32px';
    elem.style.width = '32px';
    elem.style.left = j * 32 + 'px';
    elem.style.top = i * 32 + 'px';
    ele.appendChild(elem);
  }
}

murscassable();

function murscassable() {
  const MAX_BLOCKS = 37;
  const MAX_ATTEMPTS = 1000;
  const EXCLUDED_POSITIONS = new Set(["15-11", "7-7", "15-1", "6-9","1-1","1-2","2-1","2-2"])
  const AllBlock = document.querySelectorAll('[data-bg="green"]');
  const blockMap = new Map();
  AllBlock.forEach(el => {
    const i = parseInt(el.dataset.i)
    const j = parseInt(el.dataset.j)
    blockMap.set(`${i}-${j}`, el)
  })

  let blocksPlaced = 0;
  let attempts = 0;

  while (blocksPlaced < MAX_BLOCKS && attempts < MAX_ATTEMPTS) {
    attempts++;
    const ri = Math.floor(Math.random() * 11) + 1;
    const rj = Math.floor(Math.random() * 15) + 1;
    if (EXCLUDED_POSITIONS.has(`${rj}-${ri}`)) continue;
    const div = blockMap.get(`${ri}-${rj}`);
    if (div) {
      arr.push({ top: ri * 32, left: rj * 32 });
      div.style.backgroundImage = 'url("media/block.png")';
      div.dataset.bg = "block";
      blocksPlaced++;
    }
  }
}

class enemy {
  constructor(i,j,nb) {
    this.i = i;
    this.j = j;
    this.nb = nb;
    this.index = -1
    this.changeMove = 0
    this.checkout = 250
    this.Eattempts = 0
    this.enemy = document.createElement('div')
    this.enemy.style.position = 'absolute'
    this.enemy.style.width = '32px'
    this.enemy.style.height = '32px'
    this.enemy.style.left = this.j + 'px'
    this.enemy.style.top = this.i + 'px'
    this.enemy.classList = 'enemy'+this.nb
    this.enemy.dataset.j = this.j;
    this.enemy.dataset.i = this.i;
    this.enemy.style.backgroundImage = 'url("media/enemy.png")'
    ele.appendChild(this.enemy)
  }
  enemyMove = () =>  {
    this.Eattempts +=   1
    if (this.Eattempts > this.checkout) {
      if (this.changeMove != 3) {
        if (CanMove(this.i+ this.index, this.j)) {
          this.i += this.index
          this.enemy.style.top = this.i + 'px'
          this.changeMove = 3
          this.Eattempts = 0
          this.checkout = Math.floor(Math.random() * (450) + 50)
        } else if (CanMove(this.i - this.index, this.j)) {
          this.index = this.index * -1
          this.i+= this.index
          this.enemy.style.top = this.i+ 'px'
          this.changeMove = 3
          this.Eattempts = 0
          this.checkout = Math.floor(Math.random() * (450) + 50)
        }
      } else {
        if (CanMove(this.i, this.j + this.index)) {
          this.j += this.index
          this.enemy.style.left = this.j + 'px'
          this.changeMove = 0
          this.Eattempts = 0
        } else if (CanMove(this.i, this.j - this.index)) {
          this.index = this.index * -1
          this.j += this.index
          this.enemy.style.left = this.j + 'px'
          this.changeMove = 0
          this.Eattempts = 0
        }
      }
    }
  
    if (this.changeMove < 3) {
      if (CanMove(this.i, this.j + this.index)) {
        this.j += this.index
        this.enemy.style.left = this.j + 'px'
      } else {
        this.changeMove++
        this.index = -1 * this.index
      }
    } else {
      if (CanMove(this.i + this.index, this.j)) {
        this.i += this.index
        this.enemy.style.top = this.i + 'px'
      } else {
        this.changeMove = this.changeMove - 1
        if (this.changeMove < 3) {
          this.changeMove = 0
        }
        this.index = 1 * this.index
      }
  
    }
    requestAnimationFrame(this.enemyMove)
  }
   DestroyEnemy = () =>  {
    if ((Math.abs(this.i - iBombe) < 32 && Math.abs(this.j - jBombe) < 64) || (Math.abs(jBombe - this.j) < 32 && Math.abs(iBombe - this.i) < 64)) {
      updateScore(100)
      this.enemy.style.background = 'url("media/destroy_enemy.png")';
      this.startTime = Date.now()
      requestAnimationFrame(this.animate);
    }
  
  }

  animate =() =>{
    const animationSteps = [
      { time: 100, position: "0px 0px" },
      { time: 500, position: "-32px 0px" },
      { time: 1000, position: "-64px 0px" },
      { time: 1500, position: "-96px 0px" }
    ];

    const elapsed = Date.now() - this.startTime;
    let currentStep = 0;
    while (currentStep < animationSteps.length && elapsed >= animationSteps[currentStep].time) {
      this.enemy.style.backgroundPosition = animationSteps[currentStep].position;
      currentStep++;
    }
    if (elapsed < 2000) {
      requestAnimationFrame(this.animate);
    } else {
      this.enemy.remove();
      this.i = 0;
      this.j = 0;
    }
  }
  DestroyHero = ()=> {
    if (Math.abs(this.i - Top) < 32 && Math.abs(this.j - Left) < 32){
      return true
  }else {
    return false
  }
}
}

const enemy0 = new enemy(352,480,0) 
const enemy1 = new enemy(32,480,1)
const enemy2 = new enemy(288,192,2)
const enemy3 = new enemy(224,224,3)
function globalMove() {
  enemy0.enemyMove();
  enemy1.enemyMove();
  enemy2.enemyMove();
  enemy3.enemyMove();
}
//equestAnimationFrame(globalMove);


const hero = document.createElement('div')
hero.style.position = 'absolute'
hero.style.width = '32px'
hero.style.height = '32px'
hero.style.left = '32px'
hero.style.top = '32px'
hero.tabIndex = 0
hero.style.backgroundImage = 'url("media/move_down.png")';
hero.style.outline = 'none'
ele.appendChild(hero)

hero.focus()
var Left = 32
var Top = 32
var Flex = []
function changerAnimation(walk) {
  switch (walk) {
    case 1:
      hero.style.backgroundPosition = "0px 0px";
      break;
    case 2:
      hero.style.backgroundPosition = "-32px 0px";
      break;
    case 3:
      hero.style.backgroundPosition = "-64px 0px";
      break;
    case 4:
      hero.style.backgroundPosition = "-96px 0px";
      break;
  }
}


Pbombe = document.querySelectorAll('[data-bg="green"]')
Pbombe.forEach(element => {
  BombePlace.push({ top: (Number(element.dataset.i) * 32), left: (Number(element.dataset.j) * 32) })
});

function changerbackground(direction) {
  switch (direction) {
    case 'droite':
      hero.style.backgroundImage = 'url("media/move_right.png")';
      break;
    case 'gauche':
      hero.style.backgroundImage = 'url("media/move_left.png")';
      break;
    case 'haut':
      hero.style.backgroundImage = 'url("media/move_up.png")';
      break;
    case 'bas':
      hero.style.backgroundImage = 'url("media/move_down.png")';
      break;
  }
}

var BombId
var iBombe
var jBombe

function Bombe(i, j) {
  const startTime = Date.now()
  for (let x = 0; x < BombePlace.length; x++) {
    if (BombePlace[x].top == i) {
      if (Math.abs(j - (BombePlace[x].left)) <= 16) {
        iBombe = i
        jBombe = BombePlace[x].left
        break
      }
    } else {
      if (BombePlace[x].left == j) {
        if (Math.abs(i - (BombePlace[x].top)) <= 16) {
          iBombe = BombePlace[x].top
          jBombe = j
          break
        }

      }
    }
  }

  const bombe = document.createElement('div')
  bombe.style.position = 'absolute'
  bombe.style.width = '32px'
  bombe.style.height = '32px'
  bombe.style.left = jBombe + 'px'
  bombe.style.top = iBombe + 'px'
  bombe.classList = 'bombe'
  bombe.style.backgroundImage = 'url("media/bomb.png")'
  ele.appendChild(bombe)
  arr.push({ top: iBombe, left: jBombe })
  BombId = requestAnimationFrame(function animateBomb() {
    const elapsed = Date.now() - startTime;
    if (elapsed < 3500) {
      BombId = requestAnimationFrame(animateBomb);
    } else {
      const bomb = document.querySelector('.bombe');
      bomb.remove()
      Destroy(iBombe, jBombe-32);
      Destroy(iBombe, jBombe+32);
      Destroy(iBombe-32, jBombe);
      Destroy(iBombe+32, jBombe);
      arr.pop();
      BombId = undefined;
    }
  });
}
function Destroy(i, j) {
  const div1 = document.querySelector(`div[data-i="${i / 32}"][data-j="${(j) / 32}"][data-bg="block"]`)
  const startTime = Date.now()
  const animationSteps = [
    { time: 50, position: "-32px 0px" },
    { time: 100, position: "-64px 0px" },
    { time: 150, position: "-96px 0px" }
  ];
  if (div1 !== null) {
    function animate() {
      const elapsed = Date.now() - startTime;
      let currentStep = 0;
      while (currentStep < animationSteps.length && elapsed >= animationSteps[currentStep].time) {
        div1.style.backgroundPosition = animationSteps[currentStep].position;
        currentStep++;
      }
      if (elapsed < 200) {
        requestAnimationFrame(animate);
      } else {
        div1.style.backgroundImage = `url("media/greenBlock.png")`;
        div1.dataset.bg = "green";
        BombePlace.push({ top: i, left: j});
        arr = arr.filter(x => x.top !== i || x.left !== j);
      }
    }

    requestAnimationFrame(animate);
  }
}

function updateScore(points) {
  score += points
  document.getElementById('score').textContent = `Score: ${score}`
}


function togglePause() {
  console.log(isPaused)
  isPaused = !isPaused
 // document.getElementById('pauseMenu').style.display = isPaused ? 'block' : 'none'
}




function CanMove(ihero, jhero) {
  for (let x = 0; x < arr.length; x++) {
    if (Math.abs(arr[x].top - ihero) >= 32 || Math.abs(arr[x].left - jhero) >= 32) {
      continue
    }
    console.log(ihero,jhero,arr[x])
    return false
  }
  return true

}

function FlexMoveDown(ihero, jhero) {
  var e = 12
  for (let x = 0; x < arr.length; x++) {
    if (
      Math.abs(arr[x].left - jhero) < 32 &&
      (32 - Math.abs(arr[x].left - jhero)) < e &&
      arr[x].top - 32 === ihero
    ) {
      if (arr[x].left - jhero < 0) {
        jhero = arr[x].left + 32
        ihero = arr[x].top - 32
        console.log([ihero, jhero])
        return [ihero, jhero]
      } else {
        jhero = arr[x].left - 32
        ihero = arr[x].top - 32
        return [ihero, jhero]
      }

    }

  }
  return [ihero, jhero]

}


function FlexMoveUp(ihero, jhero) {
  var e = 12
  for (let x = 0; x < arr.length; x++) {
    if (
      Math.abs(arr[x].left - jhero) < 32 &&
      (32 - Math.abs(arr[x].left - jhero)) < e &&
      arr[x].top + 32 === ihero
    ) {
      if (arr[x].left - jhero <= 0) {
        jhero = arr[x].left + 32
        ihero = arr[x].top + 32
        return [ihero, jhero]
      } else {
        jhero = arr[x].left - 32
        ihero = arr[x].top + 32
        return [ihero, jhero]
      }

    }

  }
  return [ihero, jhero]

}

function FlexMoveLeft(ihero, jhero) {
  var e = 12
  for (let x = 0; x < arr.length; x++) {
    if (
      Math.abs(arr[x].top - ihero) < 32 &&
      (32 - Math.abs(arr[x].top - ihero)) < e &&

      (arr[x].left + 32 == jhero)) {
      if (arr[x].top - ihero <= 0) {
        jhero = arr[x].left + 32
        ihero = arr[x].top + 32
        return [ihero, jhero]
      } else {
        jhero = arr[x].left + 32
        ihero = arr[x].top - 32
        return [ihero, jhero]
      }

    }

  }
  return [ihero, jhero]

}


function FlexMoveRight(ihero, jhero) {
  var e = 12
  for (let x = 0; x < arr.length; x++) {
    if (
      Math.abs(arr[x].top - ihero) < 32 &&
      (32 - Math.abs(arr[x].top - ihero)) < e &&

      (arr[x].left - 32 == jhero)) {
      if (arr[x].top - ihero <= 0) {
        jhero = arr[x].left - 32
        ihero = arr[x].top + 32
        return [ihero, jhero]
      } else {
        jhero = arr[x].left - 32
        ihero = arr[x].top - 32
        return [ihero, jhero]
      }

    }

  }
  return [ihero, jhero]

}

function PlaceFreeUp(i, j) {
  i = Math.floor(i / 32)
  j = j / 32
  const Place = document.querySelector(`div[data-i="${i}"][data-j="${j}"][data-bg="green"]`)
  if (Place) {
    return true
  }
  return false
}

function PlaceFreeDown(i, j) {
  i = Math.ceil(i / 32)
  j = j / 32
  const Place = document.querySelector(`div[data-i="${i}"][data-j="${j}"][data-bg="green"]`)
  if (Place) {
    return true
  }
  return false
}
function PlaceFreeLeft(i, j) {
  i = i / 32
  j = Math.floor(j / 32)
  const Place = document.querySelector(`div[data-i="${i}"][data-j="${j}"][data-bg="green"]`)
  if (Place) {
    return true
  }
  return false
}

function PlaceFreeRight(i, j) {
  i = i / 32
  j = Math.ceil(j / 32)
  const Place = document.querySelector(`div[data-i="${i}"][data-j="${j}"][data-bg="green"]`)
  if (Place) {
    return true
  }
  return false
}

var Right = 1
var Down = 1
var Up = 1
var LLeft = 1
hero.addEventListener('keydown', function (event) {
  switch (event.key) {
    case "ArrowDown":
      changerbackground('bas')
      changerAnimation(Down)
      Down++
      if (Down > 4) {
        Down = 1
      }
      Flex = FlexMoveDown(Top, Left)
      Top = Flex[0]
      Left = Flex[1]
      if (CanMove(Top + 2, Left) || (!CanMove(Top, Left) && PlaceFreeDown(Top, Left))) {
        Top += 2
        hero.style.top = Top + 'px'
        hero.style.left = Left + 'px'
      }
      break;
    case "ArrowUp":
      changerbackground('haut')
      changerAnimation(Up)
      Up++
      if (Up > 4) {
        Up = 1
      }
      Flex = FlexMoveUp(Top, Left)
      Top = Flex[0]
      Left = Flex[1]
      if (CanMove(Top - 2, Left) || (!CanMove(Top, Left) && PlaceFreeUp(Top, Left))) {
        Top -= 2
        hero.style.top = Top + 'px'
        hero.style.left = Left + 'px'
      }
      break;
    case "ArrowLeft":
      changerbackground('gauche')
      changerAnimation(LLeft)
      LLeft++
      if (LLeft > 4) {
        LLeft = 1
      }
      Flex = FlexMoveLeft(Top, Left)
      Top = Flex[0]
      Left = Flex[1]
      if (CanMove(Top, Left - 2) || (!CanMove(Top, Left) && PlaceFreeLeft(Top, Left))) {
        Left -= 2
        hero.style.top = Top + 'px'
        hero.style.left = Left + 'px'
      }
      break;
    case "ArrowRight":
      changerbackground('droite')
      changerAnimation(Right)
      Right++
      if (Right > 4) {
        Right = 1
      }
      Flex = FlexMoveRight(Top, Left)
      Top = Flex[0]
      Left = Flex[1]
      if (CanMove(Top, Left + 2) || (!CanMove(Top, Left) && PlaceFreeRight(Top, Left))) {
        Left += 2
        hero.style.top = Top + 'px'
        hero.style.left = Left + 'px'
      }
      break;
    case "x":
      if (BombId == undefined) {
        Bombe(Top, Left)
        const bombStartTime = Date.now();
        function checkExplosion(){
          const elapsed = Date.now() - bombStartTime;

          if (elapsed < 3500) {
            requestAnimationFrame(checkExplosion);
          } else {
            enemy0.DestroyEnemy();
            enemy1.DestroyEnemy();
            enemy2.DestroyEnemy();
            enemy3.DestroyEnemy();
            if ((Math.abs(iBombe - Top) < 32 && Math.abs(jBombe - Left) < 64) || (Math.abs(jBombe - Left) < 32 && Math.abs(iBombe - Top) < 64) ){
              HeroBomb = true

            }
          }
        }

        requestAnimationFrame(checkExplosion);
      }
      break;
    case " ":
      togglePause()
      break
  }
})

function GameOver() {
  if (enemy0.DestroyHero() || enemy1.DestroyHero() || enemy2.DestroyHero() ||enemy3.DestroyHero()||HeroBomb) {
    hero.style.background = `url("media/destroy_hero.png")`
    hero.blur()
    const startTime = Date.now()
    const animationSteps = [
      { time: 100, position: "0px 0px" },
      { time: 500, position: "-32px 0px" },
      { time: 1000, position: "-64px 0px" },
      { time: 1500, position: "-96px 0px" }
    ];

    function animate() {
      const elapsed = Date.now() - startTime;
      let currentStep = 0;
      while (currentStep < animationSteps.length && elapsed >= animationSteps[currentStep].time) {
        hero.style.backgroundPosition = animationSteps[currentStep].position;
        currentStep++;
      }
      if (elapsed < 2000) {
        requestAnimationFrame(animate);
      } else {
        hero.remove();
      }
    }

    requestAnimationFrame(animate);
  }
  requestAnimationFrame(GameOver)
}

requestAnimationFrame(GameOver)
